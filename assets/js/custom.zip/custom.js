$(document).ready(function(){ 

		/*********** Nav menu ***************/
		$('.nav-icon').click(function(){
			$('.menubar-area').slideToggle();
		});
		
		$('.token-chart').owlCarousel({
			loop:true,
			nav:true,
			margin:10,
			autoplay:true,
			autoplayTimeout:4000,
			items:1,
		});
		$('.timeline-single-area').owlCarousel({
			loop:true,
			nav:false,
			margin:10,
			autoplay:true,
			autoplayTimeout:4000,
			dots:false,
			responsive:{
				0:{
					items:1,
				},
				450:{
					items:2,
				},
				768:{
					items:3
				},
				992:{
					items:4
				},
				1200:{
					items:5
				}
			}
		});
		
		$('.popup-with-zoom-anim').magnificPopup({
			type: 'inline',

			fixedContentPos: false,
			fixedBgPos: true,

			overflowY: 'auto',

			closeBtnInside: true,
			preloader: false,
			
			midClick: true,
			removalDelay: 300,
			mainClass: 'my-mfp-zoom-in',
    callbacks: {
        open: function() {

            // https://github.com/dimsemenov/Magnific-Popup/issues/125
            $('html').css('margin-right', 0);

            // Play video on open:
            $(this.content).find('video')[0].play();

        },
        close: function() {

            // Reset video on close:
            $(this.content).find('video')[0].load();

        }
    }
			
		});
		
		

});
	